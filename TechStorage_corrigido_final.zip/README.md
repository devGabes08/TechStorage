 Link para trello: https://trello.com/invite/b/68db0d394f68b2a936b8153b/ATTIce5a9a452e20e1aa4efa2585858adae6032E802E/sprint-versao-1

 Link para o Figma: https://www.figma.com/design/jNaRg9zpaM9gO6yvPkiWLc/Untitled?t=Wim1fodU7ASB6OmD-1
