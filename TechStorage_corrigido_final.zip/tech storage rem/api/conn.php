<?php
$host = "localhost";
$user = "root";      // Usuário padrão do XAMPP
$pass = "";          // Senha em branco no XAMPP
$dbname = "armazem"; // Nome do banco (igual ao do armazem.sql)

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}
?>