<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db_config.php';

// Espera: email, senha
$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';

if (!$email || !$senha) {
    http_response_code(400);
    echo json_encode(['error' => 'email e senha são obrigatórios']);
    exit;
}

$sql = "SELECT id_usuario, nome_completo, senha_hash, papel FROM usuarios WHERE email = ? LIMIT 1";
if ($stmt = $mysqli->prepare($sql)) {
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 0) {
        http_response_code(401);
        echo json_encode(['error' => 'Credenciais inválidas']);
        exit;
    }
    $row = $res->fetch_assoc();
    if (password_verify($senha, $row['senha_hash'])) {
        // Sucesso: retorne dados essenciais (sem senha)
        echo json_encode([
            'success' => true,
            'id_usuario' => (int)$row['id_usuario'],
            'nome_completo' => $row['nome_completo'],
            'papel' => $row['papel']
        ]);
        exit;
    } else {
        http_response_code(401);
        echo json_encode(['error' => 'Credenciais inválidas']);
        exit;
    }
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Erro na preparação da query: ' . $mysqli->error]);
}
?>