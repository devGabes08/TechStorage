<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db_config.php';

// Espera: nome_completo, email, senha, papel
$nome = $_POST['nome_completo'] ?? '';
$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';
$papel = $_POST['papel'] ?? 'FUNCIONARIO';

if (!$nome || !$email || !$senha) {
    http_response_code(400);
    echo json_encode(['error' => 'nome_completo, email e senha são obrigatórios']);
    exit;
}

// Gera hash seguro usando password_hash (BCRYPT)
$senha_hash = password_hash($senha, PASSWORD_BCRYPT);

// Insere usuário (o campo salt será vazio já que não usamos mais)
$salt = '';
$sql = "INSERT INTO usuarios (nome_completo, email, senha_hash, salt, papel) VALUES (?, ?, ?, ?, ?)";
if ($stmt = $mysqli->prepare($sql)) {
    $stmt->bind_param('sssss', $nome, $email, $senha_hash, $salt, $papel);
    if (!$stmt->execute()) {
        http_response_code(500);
        echo json_encode(['error' => 'Erro ao inserir usuário: ' . $stmt->error]);
        exit;
    }
    $id = $stmt->insert_id;
    echo json_encode(['success' => true, 'id_usuario' => $id]);
    $stmt->close();
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Erro na preparação da query: ' . $mysqli->error]);
}
?>